namespace UnityEngine.TestTools
{
    public interface IPrebuildSetup
    {
        void Setup();
    }
}
